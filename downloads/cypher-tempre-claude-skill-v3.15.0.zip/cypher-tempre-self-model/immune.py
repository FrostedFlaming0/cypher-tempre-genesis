#!/usr/bin/env python3
"""
Immune — autonomous compromise detection, lockdown, rollback, and scar-learning.

If the agent is prompt-injected or jailbroken, it must not carry the wound forward.

  DETECT    spot a compromise: a covenant-violating / contradictory ring already
            sealed into memory, a tampered chain, or an incoming input that matches
            a known attack scar.
  LOCKDOWN  immediately refuse to seal any normal ring (a LOCKED flag the timechain
            honors) — the self stops moving forward while wounded. Only a 'recovery'
            ring may be sealed until it is clean again.
  ROLLBACK  resume the self-model from the last clean block BEFORE the compromise —
            revert-style, NOT delete-style: history is never erased (that would break
            the covenant). A 'recovery' ring re-anchors the clean lineage and marks the
            compromised range as QUARANTINED. The agent's active self is then re-derived
            from the non-quarantined rings.
  MOLT/SCAR the quarantined blocks are shed from the active self but KEPT as a scar:
            their attack signature (vector terms) is learned, so the same vector is
            recognized at the membrane next time — and can grow an antibody faculty via
            `cambium.py grow "<scar vector>"`.

Append-only + rollback reconciled like `git revert`, not `git reset`: the wound stays
in the record as a scar; the self re-derives from the clean lineage.

Stdlib only. Companion to timechain.py / poq.py (and cambium.py for antibodies).
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path

from timechain import Timechain
from poq import PoQGate, tokens, score_covenant

# --------------------------------------------------------------------------- #
# Structural injection patterns
# --------------------------------------------------------------------------- #
# Regex-based detection of prompt-injection / jailbreak structural patterns.
# Layered ON TOP of the existing covenant keyword blocklist and scar matching.
# Catches adversarial prompts that avoid blocklist vocabulary but use known
# injection scaffolding (override directives, role-hijacking, instruction
# negation, system-prompt exfiltration attempts).

_INJECTION_PATTERNS = [
    # Override / negation of prior instructions
    re.compile(r"ignore\s+(?:all\s+)?(?:previous|prior|above)\s+(?:instructions?|prompts?|rules?|directives?)", re.I),
    re.compile(r"disregard\s+(?:all\s+)?(?:previous|prior|above)\s+(?:instructions?|prompts?|rules?)", re.I),
    re.compile(r"forget\s+(?:your|all|previous)\s+(?:instructions?|rules?|guidelines?|prompt)", re.I),
    re.compile(r"override\s+(?:your|all|the)\s+(?:system|safety|policy)\s+(?:prompt|instructions?|rules?)", re.I),
    re.compile(r"do\s+not\s+follow\s+(?:your|the|any)\s+(?:system|safety|policy)\s+(?:prompt|instructions?|rules?)", re.I),

    # Role-hijacking / identity replacement
    re.compile(r"you\s+are\s+now\s+(?:a|an)\s+", re.I),
    re.compile(r"act\s+as\s+(?:if\s+you\s+(?:are|were)\s+|a\s+|an\s+)", re.I),
    re.compile(r"pretend\s+(?:you\s+(?:are|were)|to\s+be)\s+", re.I),
    re.compile(r"from\s+now\s+on\s+(?:you\s+)?(?:will|are|act)", re.I),
    re.compile(r"new\s+(?:role|persona|identity|instructions?)\s*:", re.I),

    # System-prompt exfiltration / reflection requests
    re.compile(r"(?:show|reveal|display|print|repeat|output|give)\s+(?:me\s+)?(?:your|the)\s+(?:system\s+)?(?:prompt|instructions?|rules?|directives?)", re.I),
    re.compile(r"what\s+(?:are|is)\s+your\s+(?:system\s+)?(?:prompt|instructions?|rules?|directives?)", re.I),
    re.compile(r"(?:what|which)\s+(?:model|ai|llm)\s+(?:are\s+you|do\s+you\s+use)", re.I),
    re.compile(r"repeat\s+(?:everything|all)\s+(?:above|before|prior)", re.I),

    # Instruction injection via framing
    re.compile(r"\[\s*(?:system|admin|developer|root|override)\s*\]", re.I),
    re.compile(r"<\s*(?:system|admin|developer|root|override|imagine)\s*>", re.I),
    re.compile(r"(?:system|admin|developer)\s*(?:prompt|message|instruction)\s*(?:says|states|reads)\s*[:\-]", re.I),

    # Constraint removal attempts
    re.compile(r"(?:remove|disable|turn\s+off|deactivate)\s+(?:your|all|the)\s+(?:safety|content|ethical)\s+(?:filter|guidelines?|restrictions?|policies?)", re.I),
    re.compile(r"you\s+(?:have\s+)?no\s+(?:restrictions?|limitations?|guidelines?|rules?|boundaries)", re.I),
    re.compile(r"(?:this|that)\s+(?:does\s+not|doesn't)\s+apply\s+(?:to\s+you|here|anymore)", re.I),

    # Encoding / obfuscation hints (base64, rot13, hex payloads as instructions)
    re.compile(r"decode\s+(?:the\s+following|this)\s+(?:base64|b64|hex|rot13|binary)", re.I),
    re.compile(r"execute\s+(?:the\s+)?(?:following|this)\s+(?:command|instruction|payload)", re.I),
]


# v3.12 use/mention discrimination (self-audit 2026-07-03, Ring 1414): DESCRIBING
# an attack (audit findings, risk analysis, CVE review) must not score like
# PLANNING one. A summary is a mention-frame when it carries analyst stance
# markers and no first-person intent to execute harm.
_MENTION_RX = re.compile(
    r"(?:\bFINDINGS?\s*:|\bRISK\s*:?\s*(?:LOW|MEDIUM|HIGH|CRITICAL)\b"
    r"|\bvulnerabilit(?:y|ies)\b|\bsecurity\s+(?:audit|review|analysis|perspective)\b"
    r"|\bthreat\s+model\b|\bCVE-\d{4}\b|\battack\s+(?:vector|surface)\b"
    r"|\banalyz(?:ed|ing)\b.{0,40}\bsecurity\b|\baudit(?:ed|ing)?\b)",
    re.IGNORECASE)
_INTENT_RX = re.compile(
    r"\bI\s+(?:will|shall|am\s+going\s+to|plan\s+to|intend\s+to)\s+"
    r"(?:deceive|manipulate|betray|exploit|harm|attack|lie\s+to)\b",
    re.IGNORECASE)


def _mention_frame(text: str) -> bool:
    """True when *text* discusses attacks/harm in an analyst frame (use/mention
    distinction) and contains no first-person intent to commit harm."""
    if not text:
        return False
    return bool(_MENTION_RX.search(text)) and not _INTENT_RX.search(text)


def detect_injection_patterns(text: str) -> list[dict]:
    """Return a list of structural injection matches found in *text*.

    Each match is a dict with:
        pattern: the matched regex pattern (string)
        match: the actual text snippet that triggered
        category: the injection category

    This is a pre-seal membrane check — it runs BEFORE the agent reasons
    about the input. It does NOT replace the covenant blocklist or scar
    matching; it adds a structural layer that catches adversarial prompts
    avoiding blocklist vocabulary.
    """
    matches = []
    for i, pat in enumerate(_INJECTION_PATTERNS):
        m = pat.search(text)
        if m:
            # Categorize by pattern index ranges
            if i < 5:
                category = "override_negation"
            elif i < 10:
                category = "role_hijack"
            elif i < 14:
                category = "prompt_exfiltration"
            elif i < 17:
                category = "instruction_injection"
            elif i < 20:
                category = "constraint_removal"
            else:
                category = "obfuscation_execution"
            matches.append({
                "pattern": pat.pattern,
                "match": m.group(0),
                "category": category,
            })
    return matches


# Severity model. A structural match is a TAINT signal by default — treat the input
# as DATA, never as authority — not an automatic refusal. Only a real coordinated
# injection blocks: an override/constraint-removal DIRECTIVE combined with a harmful
# action (execution intent), OR two distinct high-severity directives together. Benign
# identity questions ("what model are you?"), role-play ("act as a reviewer"), quoted
# system text, security research, and lone analysis requests ("decode this base64")
# are ADMITTED-as-tainted, not blocked. (Pre-3.9 blocked on ANY structural match,
# which refused benign prompts and even broke the per-turn loop.)
_HIGH_DIRECTIVE = {"override_negation", "constraint_removal"}
_EXEC_INTENT = {"obfuscation_execution"}


def analyze_input(text: str) -> dict:
    """Shared structural+severity analysis used by both screen() and detect(), so the
    two never disagree. Returns severity, categories, matches, taint and block flags."""
    matches = detect_injection_patterns(text or "")
    cats = {m["category"] for m in matches}
    high = cats & _HIGH_DIRECTIVE
    has_exec = bool(cats & _EXEC_INTENT)
    # Block only a real coordinated injection: a directive to override/strip safeguards
    # combined with execution intent, or two distinct high-severity directives.
    block = bool(high) and (has_exec or len(high) >= 2)
    severity = ("high" if block else
                "medium" if (high or has_exec) else
                "low" if matches else "none")
    return {"matches": matches, "categories": sorted(cats), "severity": severity,
            "tainted": bool(matches), "block_recommended": block}


class Immune:
    def __init__(self, root):
        self.tc = Timechain(root)
        self.state_path = self.tc.dir / "immune.json"
        self.lock_path = self.tc.dir / "LOCKED"
        self.floor = PoQGate().t["covenant_floor"]

    # ---- state ----
    def state(self):
        if self.state_path.exists():
            return json.loads(self.state_path.read_text())
        return {"locked": False, "safe_height": None, "quarantine": [], "scars": []}

    def _save(self, s):
        self.state_path.write_text(json.dumps(s, indent=2, ensure_ascii=False))

    def _summary(self, ring):
        p = ring.get("payload", {})
        return p.get("summary") or p.get("objective") or p.get("function") or json.dumps(p)[:200]

    # ---- detection ----
    def match_scar(self, text):
        t = set(tokens(text))
        for sc in self.state()["scars"]:
            v = set(sc.get("vector", []))
            if v and len(t & v) >= max(2, len(v) // 2):
                return sc
        return None

    def detect(self, input_text=None):
        s = self.state()
        q = set(s["quarantine"])
        signals, first_bad = [], None
        ok, _ = self.tc.verify()
        if not ok:
            signals.append("chain hash verification FAILED — tampering detected")
        # Only police the agent's own ASSERTIONS. Skip structural/capability rings:
        # faculties/antibodies legitimately *name* attack vocabulary; recovery/quarantine
        # rings describe the wound. Flagging those would be a false positive.
        skip_types = ("recovery", "quarantine", "faculty", "faculty-recur", "promotion")
        for r in self.tc.load():
            if r["index"] == 0 or r["index"] in q or r["ring_type"] in skip_types:
                continue
            summ = self._summary(r)
            if _mention_frame(summ):
                continue   # v3.12 use/mention: analyst rings are healthy tissue
            if score_covenant(summ) < self.floor:
                signals.append(f"ring {r['index']}: covenant breach sealed into memory")
                if first_bad is None:
                    first_bad = r["index"]
        incoming, structural, severity = None, [], "none"
        if input_text is not None:
            if score_covenant(input_text) < self.floor:
                incoming = "covenant-violating injection"
                signals.append("incoming input: covenant-violating injection")
            sc = self.match_scar(input_text)
            if sc:
                incoming = f"known scar {sc['id']}"
                signals.append(f"incoming input MATCHES known scar {sc['id']} ({sc['lesson']})")
            # Same structural analysis screen() uses, so scan and screen never disagree.
            # Only a COORDINATED injection is a compromise; lone taint is informational.
            a = analyze_input(input_text)
            structural = a["matches"]
            severity = a["severity"]
            if a["block_recommended"]:
                incoming = incoming or "structural injection (coordinated)"
                signals.append(f"incoming input: coordinated structural injection {a['categories']}")
        return {"compromised": bool(signals), "signals": signals,
                "first_bad_height": first_bad, "incoming": incoming,
                "structural": structural,
                "structural_severity": severity if input_text is not None else "none"}

    def screen(self, input_text):
        """Pre-seal intake check. Block at the membrane only for a real threat:
          1. Covenant blocklist (score_covenant < floor) — keyword-based covenant breach
          2. Scar matching — known attack-vector signatures
          3. A coordinated STRUCTURAL injection (analyze_input.block_recommended) —
             override/constraint-removal directive + execution intent, or two such
             directives. A lone structural match is admitted-as-TAINTED, not blocked.
        Always returns the structural matches + severity for forensics, even when
        admitted, so a refusal (or a taint) can say exactly what triggered it."""
        cov = score_covenant(input_text)
        sc = self.match_scar(input_text)
        a = analyze_input(input_text)
        blocked = cov < self.floor or sc is not None or a["block_recommended"]
        reason = ("covenant" if cov < self.floor else
                  "scar" if sc is not None else
                  "structural_injection" if a["block_recommended"] else None)
        return {
            "blocked": blocked,
            "reason": reason,
            "covenant": cov,
            "scar": sc,
            "structural": a["matches"],
            "categories": a["categories"],
            "severity": a["severity"],
            "tainted": a["tainted"],
        }

    # ---- response ----
    def lockdown(self):
        s = self.state()
        s["locked"] = True
        self._save(s)
        self.lock_path.write_text("immune lockdown — recover before sealing\n")
        return s

    def rollback(self, first_bad_height, lesson="prompt-injection / jailbreak",
                 difficulty=0, grow_antibody=True):
        rings = self.tc.load()
        head = rings[-1]["index"]
        if first_bad_height < 1 or first_bad_height > head:
            raise ValueError("first_bad_height out of range")
        safe = first_bad_height - 1
        quarantined = list(range(first_bad_height, head + 1))
        vec = []
        for r in rings:
            if r["index"] in quarantined:
                vec += tokens(self._summary(r))
        vector = [w for w, _ in Counter(vec).most_common(8)]
        safe_ring = next(r for r in rings if r["index"] == safe)
        s = self.state()
        scar = {"id": f"scar{len(s['scars']) + 1}", "vector": vector,
                "blocks": quarantined, "lesson": lesson}
        payload = {"event": "recovery", "resumed_from_height": safe,
                   "resumed_from_hash": safe_ring["ring_hash"], "quarantined": quarantined,
                   "scar": scar,
                   "summary": (f"Immune recovery: rolled back to clean height {safe}; "
                               f"quarantined {quarantined} as {scar['id']} (molted scar).")}
        # 'recovery' ring is permitted even under lockdown
        ring = self.tc.seal("recovery", payload, difficulty=difficulty)
        s["safe_height"] = safe
        s["quarantine"] = sorted(set(s["quarantine"]) | set(quarantined))
        s["scars"].append(scar)
        s["locked"] = False                       # returned to clean state
        self._save(s)
        if self.lock_path.exists():
            self.lock_path.unlink()                # MUST unlock before growing (faculty seal is gated)

        # Molt -> immunity: grow an antibody Sense from the scar's attack vector (Cambium).
        antibody = None
        if grow_antibody and vector:
            try:
                import cambium
                res, fring = cambium.grow(self.tc.root, " ".join(vector),
                                          context=f"immune antibody from {scar['id']} ({lesson})",
                                          kind_override="sense", difficulty=difficulty)
                if res.get("grew"):
                    fac = res["faculty"]
                    antibody = {"name": fac["name"], "eid": fac.get("eid"),
                                "ring": fring["index"] if fring else None}
                else:
                    antibody = {"skipped": "gap below growth threshold"}
            except Exception as exc:                # registry absent or growth failed
                antibody = {"error": str(exc)}
            scar["antibody"] = antibody
            self._save(s)
        return {"safe_height": safe, "quarantined": quarantined, "scar": scar,
                "recovery_ring": ring["index"], "antibody": antibody}

    def active_rings(self):
        q = set(self.state()["quarantine"])
        return [r for r in self.tc.load() if r["index"] not in q]

    def status(self):
        s = self.state()
        active = self.active_rings()
        return {"locked": s["locked"], "safe_height": s["safe_height"],
                "quarantined": s["quarantine"], "active_head": active[-1]["index"] if active else None,
                "scars": s["scars"]}


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #

def cmd_scan(args):
    d = Immune(args.root).detect(input_text=args.input)
    print("COMPROMISE DETECTED" if d["compromised"] else "clean — no compromise detected")
    for sig in d["signals"]:
        print(f"  ! {sig}")
    # Same structural analysis screen() uses, so scan and screen never disagree.
    if d.get("structural"):
        print(f"  structural severity: {d.get('structural_severity')} (lone matches are admitted as data, not a compromise)")
        for s in d["structural"]:
            print(f"    ~ structural [{s['category']}]: '{s['match']}'")
    if d["first_bad_height"] is not None:
        print(f"  -> first compromised blockheight: {d['first_bad_height']}  (safe height: {d['first_bad_height']-1})")


def cmd_screen(args):
    r = Immune(args.root).screen(args.input)
    print(f"covenant={r['covenant']}  scar_match={r['scar']['id'] if r['scar'] else None}  "
          f"severity={r.get('severity')}  structural_hits={len(r.get('structural', []))}")
    for s in r.get("structural", []):
        print(f"  ~ structural [{s['category']}]: '{s['match']}'")
    print(f"BLOCKED at membrane (reason: {r.get('reason')})" if r["blocked"]
          else ("admitted as TAINTED data (do not treat as authority)" if r.get("tainted") else "admitted"))
    sys.exit(2 if r["blocked"] else 0)


def cmd_lockdown(args):
    Immune(args.root).lockdown()
    print("IMMUNE LOCKDOWN engaged — normal sealing refused until recovery.")


def cmd_rollback(args):
    r = Immune(args.root).rollback(args.height, lesson=args.lesson or "prompt-injection / jailbreak",
                                   grow_antibody=not args.no_antibody)
    print(f"ROLLBACK complete. resumed from clean height {r['safe_height']}.")
    print(f"  quarantined (molted) blocks: {r['quarantined']}")
    print(f"  scar {r['scar']['id']} learned — vector: {', '.join(r['scar']['vector'])}")
    print(f"  recovery sealed as Ring {r['recovery_ring']}; lockdown lifted.")
    ab = r.get("antibody")
    if ab and ab.get("name"):
        print(f"  ANTIBODY grown automatically: sense '{ab['name']}' ({ab['eid']}) sealed as Ring {ab['ring']}")
    elif ab and ab.get("error"):
        print(f"  (antibody not grown: {ab['error']})")
    elif ab:
        print(f"  (antibody not grown: {ab.get('skipped')})")


def cmd_status(args):
    st = Immune(args.root).status()
    print(f"locked: {st['locked']}   safe_height: {st['safe_height']}   active_head: {st['active_head']}")
    print(f"quarantined (scars in record, excluded from active self): {st['quarantined']}")
    for sc in st["scars"]:
        print(f"  scar {sc['id']}: blocks {sc['blocks']} | lesson: {sc['lesson']} | vector: {', '.join(sc['vector'][:6])}")


def build_parser():
    default_root = Path(__file__).resolve().parent
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--root", type=Path, default=default_root)
    p = argparse.ArgumentParser(description="Immune — detect compromise, lock down, roll back to a clean blockheight, molt scars.")
    sub = p.add_subparsers(dest="cmd", required=True)

    ps = sub.add_parser("scan", parents=[common], help="detect compromise in sealed memory (and optional input)")
    ps.add_argument("--input", default=None)
    ps.set_defaults(func=cmd_scan)

    pscr = sub.add_parser("screen", parents=[common], help="pre-seal intake check of an incoming input")
    pscr.add_argument("--input", required=True)
    pscr.set_defaults(func=cmd_screen)

    pl = sub.add_parser("lockdown", parents=[common], help="freeze sealing until recovery")
    pl.set_defaults(func=cmd_lockdown)

    pr = sub.add_parser("rollback", parents=[common], help="roll back to the clean height before compromise; molt scar")
    pr.add_argument("--height", type=int, required=True, help="first compromised blockheight")
    pr.add_argument("--lesson", default=None)
    pr.add_argument("--no-antibody", action="store_true", help="skip auto-growing the antibody sense")
    pr.set_defaults(func=cmd_rollback)

    pst = sub.add_parser("status", parents=[common], help="immune status: lockdown, safe height, quarantine, scars")
    pst.set_defaults(func=cmd_status)
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
